
	
jQuery(document).ready(function ($) {
	console.log("JQuery Ready");
	$("#block-networking-links-networking-links > div.content").children("a").each(function(){
		//alert($(this).html);
		$(this).hover(function(){
			console.log("hover");
			//$(this).css("background","lightgray");
			$(this).attr("extended","true");
			$(this).animate({
				"width":"110",
				"left": "+=50px"
			}, 180, function(){});
		},function(){
			$(this).attr("extended","false");
			$(this).animate({
				"width":"36",
				"left": "+=50px"
			}, 180, function(){});
		});
	});
	$("#block-networking-links-networking-links >div.content button").click(function() {
		if($("#block-networking-links-networking-links >div.content").attr("hide")=="true"){
			$("#block-networking-links-networking-links >div.content").attr("hide","false");
			$("#block-networking-links-networking-links >div.content button").children("img").each(function(i){
				if(i==0){
					$(this).attr("show","false");
				}else{
					$(this).attr("show","true");
				}
			});
		}else{
			$("#block-networking-links-networking-links >div.content").attr("hide","true");
			$("#block-networking-links-networking-links >div.content button").children("img").each(function(i){
				if(i==0){
					$(this).attr("show","true");
				}else{
					$(this).attr("show","false");
				}
			});
		}
	});
});